USE EventManagement;
select *from Event;