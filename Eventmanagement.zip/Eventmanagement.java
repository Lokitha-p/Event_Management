import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;


class JDBCUtil {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/EventManagement";
        String user = "root";
        String password = "nandy131205@#"; // Replace with your actual MySQL password
        return DriverManager.getConnection(url, user, password);
    }
}

// Event Management System with JDBC
public class Eventmanagement {

    // Create event in the database
    public void createEvent(String name, String description, String location) throws SQLException {
        String query = "INSERT INTO Event (name, description, location) VALUES (?, ?, ?)";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setString(3, location);
            stmt.executeUpdate();
            System.out.println("Event created: " + name);
        }
    }

    // Create schedule for an event with Date and Time
    public void scheduleEvent(int eventId, LocalDate date, LocalTime startTime, LocalTime endTime) throws SQLException {
        String query = "INSERT INTO Schedule (event_id, date, start_time, end_time) VALUES (?, ?, ?, ?)";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventId);
            stmt.setDate(2, Date.valueOf(date)); // Convert LocalDate to java.sql.Date
            stmt.setTime(3, Time.valueOf(startTime)); // Convert LocalTime to java.sql.Time
            stmt.setTime(4, Time.valueOf(endTime));
            stmt.executeUpdate();
            System.out.println("Event scheduled on " + date + " from " + startTime + " to " + endTime);
        }
    }

    // Create a volunteer
    public void createVolunteer(String name, String contactInfo) throws SQLException {
        String query = "INSERT INTO Volunteer (name, contact_info) VALUES (?, ?)";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, contactInfo);
            stmt.executeUpdate();
            System.out.println("Volunteer created: " + name);
        }
    }

    // Assign a task to a volunteer
    public void assignTask(int eventId, int volunteerId, String taskDescription) throws SQLException {
        String query = "INSERT INTO Task (event_id, description) VALUES (?, ?)";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, eventId);
            stmt.setString(2, taskDescription);
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int taskId = rs.getInt(1);
                String assignQuery = "INSERT INTO Assignment (event_id, volunteer_id, task_id) VALUES (?, ?, ?)";
                try (PreparedStatement assignStmt = conn.prepareStatement(assignQuery)) {
                    assignStmt.setInt(1, eventId);
                    assignStmt.setInt(2, volunteerId);
                    assignStmt.setInt(3, taskId);
                    assignStmt.executeUpdate();
                    System.out.println("Task assigned to volunteer " + volunteerId);
                }
            }
        }
    }

    // View all event schedules
    public void viewEventSchedules() throws SQLException {
        String query = "SELECT e.name AS event_name, s.date, s.start_time, s.end_time " +
                       "FROM Event e JOIN Schedule s ON e.event_id = s.event_id";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("Event Schedules:");
            while (rs.next()) {
                String eventName = rs.getString("event_name");
                Date date = rs.getDate("date");
                Time startTime = rs.getTime("start_time");
                Time endTime = rs.getTime("end_time");
                System.out.println("Event: " + eventName + " | Date: " + date + " | Time: " + startTime + " to " + endTime);
            }
        }
    }

    // Main method to interact with the user
    public static void main(String[] args) {
        Eventmanagement manager = new Eventmanagement();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Event Management System");
            System.out.println("1. Create Event");
            System.out.println("2. Schedule Event");
            System.out.println("3. Create Volunteer");
            System.out.println("4. Assign Task");
            System.out.println("5. View Event Schedules");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Event Name: ");
                        String eventName = scanner.nextLine();
                        System.out.print("Enter Event Description: ");
                        String eventDescription = scanner.nextLine();
                        System.out.print("Enter Event Location: ");
                        String eventLocation = scanner.nextLine();
                        manager.createEvent(eventName, eventDescription, eventLocation);
                        break;

                    case 2:
                        System.out.print("Enter Event ID to Schedule: ");
                        int eventIdToSchedule = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Schedule Date (YYYY-MM-DD): ");
                        LocalDate scheduleDate = LocalDate.parse(scanner.nextLine());
                        System.out.print("Enter Start Time (HH:MM): ");
                        LocalTime startTime = LocalTime.parse(scanner.nextLine());
                        System.out.print("Enter End Time (HH:MM): ");
                        LocalTime endTime = LocalTime.parse(scanner.nextLine());
                        manager.scheduleEvent(eventIdToSchedule, scheduleDate, startTime, endTime);
                        break;

                    case 3:
                        System.out.print("Enter Volunteer Name: ");
                        String volunteerName = scanner.nextLine();
                        System.out.print("Enter Volunteer Contact Info: ");
                        String contactInfo = scanner.nextLine();
                        manager.createVolunteer(volunteerName, contactInfo);
                        break;

                    case 4:
                        System.out.print("Enter Event ID: ");
                        int eventId = scanner.nextInt();
                        System.out.print("Enter Volunteer ID: ");
                        int volunteerId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Task Description: ");
                        String taskDescription = scanner.nextLine();
                        manager.assignTask(eventId, volunteerId, taskDescription);
                        break;

                    case 5:
                        manager.viewEventSchedules();
                        break;

                    case 6:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;

                    default:
                        System.out.println("Invalid option! Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }
}
